from urllib import request
from urllib.parse import urlparse
import os


url = 'https://2003mi.github.io/sides/q.html'

def download(url, file_name):
    #request and stor data in varble
    response = request.urlopen(url)
    file_content = response.read()

    #convert data to string and split the lines
    file_content_str = str(file_content.decode('utf-32'))
    lines = file_content_str.split("\\n")
    
    #Get file name and open it
    dest_url = path + str(file_name) 
    fx = open(dest_url, "w")
    # write data to file and close it
    for line in lines:
        fx.write(line + "\n")
    fx.close()


def download_fil(i_url, file_name):
    # open file and store in normal file
    dest_url = path + str(file_name) 
    request.urlretrieve(i_url,dest_url)

def getFileName(url):

    return url.rsplit('/', 1)[-1]
def rchop(thestring, ending):
  if thestring.endswith(ending):
    return thestring[:-len(ending)]
  return thestring

url = input("url:")
url = rchop(url, '/')
file_name = getFileName(url)

directory = urlparse(url)
a_path, a_filename = os.path.split(directory.path)
del a_filename
path = "./" + directory.netloc + a_path + "/"
if not os.path.exists(path):
    os.makedirs(path)
 
try:
    try:
        download(url, file_name)
    except UnicodeDecodeError:
        try:
            download_fil(url, file_name) 
        except Exception as e:
            print("error url or file not valid error code:" + e)
except Exception as e:
    print("404 side not found")
#print(downloader(url))
